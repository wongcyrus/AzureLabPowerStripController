import json
import setuptools

kwargs = json.loads(
    """
{
    "name": "azure-cloud-lab",
    "version": "1.0.0",
    "description": "infrastructure",
    "license": "MPL-2.0",
    "url": "https://github.com/wongcyrus/AzureLabPowerStripController",
    "long_description_content_type": "text/markdown",
    "author": "Cyrus Wong",
    "bdist_wheel": {
        "universal": true
    },
    "project_urls": {
        "Source": "https://github.com/wongcyrus/AzureLabPowerStripController"
    },
    "package_dir": {
        "": "src"
    },
    "packages": [
        "azure-cloud-lab.base._jsii"
    ],
    "package_data": {
        "azure-cloud-lab.base._jsii": [
            "infrastructure@1.0.0.jsii.tgz"
        ]
    },
    "python_requires": "~=3.7",
    "install_requires": [
        "cdktf-cdktf-provider-archive>=0.5.7, <0.6.0",
        "cdktf-cdktf-provider-azurerm>=0.7.7, <0.8.0",
        "cdktf-cdktf-provider-external>=0.6.7, <0.7.0",
        "cdktf-cdktf-provider-null>=0.7.7, <0.8.0",
        "cdktf-cdktf-provider-random>=0.3.7, <0.4.0",
        "cdktf>=0.11.0, <0.12.0",
        "constructs>=10.1.22, <11.0.0",
        "jsii>=1.59.0, <2.0.0",
        "publication>=0.0.3"
    ],
    "classifiers": [
        "Intended Audience :: Developers",
        "Operating System :: OS Independent",
        "Programming Language :: JavaScript",
        "Programming Language :: Python :: 3 :: Only",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Typing :: Typed",
        "License :: OSI Approved"
    ],
    "scripts": []
}
"""
)

with open("README.md", encoding="utf8") as fp:
    kwargs["long_description"] = fp.read()


setuptools.setup(**kwargs)
